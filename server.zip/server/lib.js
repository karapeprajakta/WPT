export default function calculatesum(a,b){
    return a+b;
}