import express from "express"
let app=express()
app.listen(8080,()=>{
    console.log("server is listening on port 8080")
})

app.get("/",(req,res)=>{
    res.send("hi......")
})
app.post("/postmsg",(req,res)=>{
   res.send("post it correctly...")
})

app.put("/putmsg",(req,res)=>{
    res.send("put it away..")
 })

 app.delete("/deletemsg",(req,res)=>{
    res.send("delete everything...")
 })