import calculatesum from "./lib.js";
let sum=calculatesum(10,20)
console.log(sum)