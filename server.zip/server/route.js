var express=require('express')
var router=express.Router()

router.listen(5000,()=>{
    console.log("server is listening on port 5000")
})
router.get('/', function(req,res){
res.send("book home page")
})
router.get('/about', function(req,res){
    res.send("About page")
})

router.post('/savebook/:bookid/:bookname',function(req,res){
    var id=req.params.bookid    //params for the parameters passed in request parameters
    var name=req.params.bookname
    res.send("your book with id="+bookid+" and name="+bookname+" is saved..")
})