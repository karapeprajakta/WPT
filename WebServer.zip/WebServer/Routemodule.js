var express=require('express')
var app=express.Router()

 app.get("/",(req,res)=>{
    res.send("welcome to server....")
 })

 app.get("/about",(req,res)=>{
    res.send("about this book...")
 })

 app.post("/book/savebook/:id/:bname",(req,res)=>{
    var id=req.params.id
    var name=req.params.bname
    res.send("your book with id:"+id+"with name:"+name+"is saved")
 })

 app.listen(8080,()=>{
    console.log("server is listening on port 8080");
 })