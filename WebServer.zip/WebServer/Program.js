import express from "express";
let app=express()

app.get("/", (req,res)=>{
    console.log("req arrived..")
    res.send("hiii from server....")
})

app.get("/getmsg/${id}",(req,res)=>{
    
    res.send("well done.....                                                                                 ")
})

app.post("/postmsg",(req,res)=>{
    res.send("posting data.....")
})

app.put("/putmsg",(req,res)=>{
    res.send("put msg .....")
})

app.delete("/deletemsg",(req,res)=>{
    res.send("delete everything.....")
})

app.listen(7000,()=>{
    console.log("server is listening on port 7000")
})
